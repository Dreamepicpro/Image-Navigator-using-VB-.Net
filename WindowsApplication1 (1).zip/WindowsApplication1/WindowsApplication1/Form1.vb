﻿Imports System.IO
Public Class Form1
    Dim startpage As Integer
    Dim previouspage As Integer
    Dim endpage As Integer
    Dim pageindex As Integer = 0
    Dim arylst As New ArrayList()
    Dim imgfilelst As String()


    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        lblNum.Text = "0"
        lblDen.Text = "0"

        imgfilelst = Directory.GetFiles("D:\Arun\imgs", "*.jpg", SearchOption.AllDirectories)

        If (imgfilelst.Length > 0) Then
            Dim i As Integer = 0

            For i = 0 To imgfilelst.Length - 1
                arylst.Add(imgfilelst(i).ToString())

            Next

        End If
        If arylst.Count > 0 Then
            pbImage.Image = Image.FromFile(arylst(0).ToString())
            pbImage.ImageLocation = arylst(0).ToString()
            pbImage.SizeMode = PictureBoxSizeMode.StretchImage
            btnNext.Enabled = True
            btnPrevious.Enabled = False
            btnGoto.Enabled = False
            pageindex = 0

            lblNum.Text = "1"
            lblDen.Text = imgfilelst.Length



        End If
        startpage = 0
        endpage = 0
        previouspage = 0

        startpage = pageindex
        
    End Sub

    Private Sub btnGoto_Click(sender As Object, e As EventArgs) Handles btnGoto.Click

        btnPrevious.Enabled = True
        btnNext.Enabled = True

        pageindex = txtGoto.Text - 1

        lblNum.Text = txtGoto.Text
        For i As Integer = 0 To arylst.Count - 1
            If i = pageindex Then
                pageindex = i
                Exit For
            End If
        Next

        If previouspage = 0 And pageindex > startpage Then
            endpage = endpage + 1
        ElseIf previouspage <> 0 Then
            previouspage = previouspage - 1

        End If

        pbImage.Image = Image.FromFile(arylst(pageindex).ToString())

        pbImage.ImageLocation = arylst(pageindex).ToString()
        pbImage.SizeMode = PictureBoxSizeMode.StretchImage

        If pageindex < arylst.Count - 1 Then
            btnNext.Enabled = True
        Else
            btnPrevious.Enabled = True
            btnNext.Enabled = False
            pbImage.SizeMode = PictureBoxSizeMode.StretchImage

            If pageindex < arylst.Count - 1 Then
                btnNext.Enabled = True
            Else
                btnPrevious.Enabled = True
                btnNext.Enabled = False


            End If
        End If
        btnNext.Enabled = True



    End Sub

    Private Sub btnPrevious_Click(sender As Object, e As EventArgs) Handles btnPrevious.Click
        btnPrevious.Enabled = True
        btnNext.Enabled = True
        lblNum.Text = pageindex
        btnPrevious.Enabled = True
        btnNext.Enabled = True
        pageindex = pageindex - 1
        If startpage < pageindex Then
            previouspage = previouspage + 1
        End If
        pbImage.Image = Image.FromFile(arylst(pageindex).ToString())
        pbImage.ImageLocation = arylst(pageindex).ToString()
        pbImage.SizeMode = PictureBoxSizeMode.StretchImage
        If pageindex <> 0 Then
            btnPrevious.Enabled = True
        Else
            btnPrevious.Enabled = False

        End If

    End Sub

    Private Sub btnNext_Click(sender As Object, e As EventArgs) Handles btnNext.Click
        btnPrevious.Enabled = True
        btnNext.Enabled = True
        pageindex = pageindex + 1

        If previouspage = 0 And pageindex > startpage Then
            endpage = endpage + 1
        ElseIf previouspage <> 0 Then
            previouspage = previouspage - 1
        End If
        pbImage.Image = Image.FromFile(arylst(pageindex).ToString())
        pbImage.ImageLocation = arylst(pageindex).ToString()
        pbImage.SizeMode = PictureBoxSizeMode.StretchImage

        If pageindex < arylst.Count - 1 Then
            btnNext.Enabled = True
        Else
            btnPrevious.Enabled = True
            btnNext.Enabled = False

        End If
        lblNum.Text = pageindex + 1
    End Sub

    Private Sub txtGoto_TextChanged(sender As Object, e As EventArgs) Handles txtGoto.TextChanged
        btnGoto.Enabled = True

    End Sub
End Class
